/* ============================================
   LOWPASS — Budget ← Operations derived-line reconcile

   Populates the budget's Accommodation / Salary / Per Diem sections
   from the source Operations modules, mirroring the existing gear-hire
   reconcile in GET /api/budget/line-items. Derived lines are read-only
   in the budget and edited at source.

   Sources (READ-only — we never write the Operations tables):
     - Accommodation ← hotels / rooms / room_assignments
         one derived line per hotel; est/actual = Σ(room.cost_amount ×
         nights) over that hotel's room assignments.
         source_entity_type='hotel_booking', hotel_id = hotels.id.
         (Enhances the cost=0 placeholder line that budget/hotels
         already creates — same source_entity_type + hotel_id, so this
         find-or-creates and fills in the real total without colliding.)
     - Salary  ← payroll_entries.total_fee summed per personnel_rates
         person. source_entity_type='payroll'.
     - Per Diem ← payroll_entries.total_per_diem per person.
         source_entity_type='payroll_per_diem'.

   Idempotent: create / update / delete only rows carrying the matching
   source_entity_type; manual lines are never touched. Target sections
   are auto-created when there's derived data to place. The whole pass
   is wrapped so a source hiccup can never break the budget page render.
   ============================================ */

import type { SupabaseClient } from '@supabase/supabase-js';
// b2 — Salary/Per-Diem derived lines now sum each person's rate lines
// (personnel_rate_lines × rate_types) via computeTotals, so custom types feed the
// budget too. Reconciles to legacy for the 5 defaults + day_rate — proven in
// reconcile.harness.ts. Advance stays the rate-card single-source (flat_once ×1).
import { countDayStatuses, computeTotals } from '@/lib/payroll/fees';
import { loadTourRateContext, rateLinesFor } from '@/lib/payroll/loadRateLines';
import { resolveActiveVersion } from '@/server/budget/versions';
import { derivedUpdatePayload, derivedInsertProposed } from '@/server/budget/derivedLockPolicy';

/** Versioning context for one reconcile pass (§3a): when the active version is
 *  APPROVED the derived feeds flow to ACTUALS only (the locked proposed baseline
 *  is frozen); when DRAFT they write proposed (column + the draft snapshot). */
interface VersionCtx {
  locked: boolean;
  draftVersionId: string | null;
}

const SECTION_ACCOMMODATION = 'Accommodation';
// Phase S — create the TEMPLATE name (plural) so a later template application
// find-or-creates the same section; alias-match the singular so an existing
// reconcile-made "Salary"/"Per Diem" is adopted, never twinned.
const SECTION_SALARY = 'Salaries';
const SALARY_ALIASES = ['Salary'];
const SECTION_PER_DIEM = 'Per Diems';
const PER_DIEM_ALIASES = ['Per Diem'];

/** Distinguishes the two payroll-derived line families (same person id,
 *  different budget line) and the hotel family. */
export const DERIVED_SOURCE_TYPES = [
  'hotel_booking',
  'payroll',
  'payroll_per_diem',
] as const;

type Desired = {
  /** budget_line_items.source_entity_id (hotels.id or personnel_rates.id) */
  sourceId: string;
  label: string;
  /** proposed_cost === actual_cost === total (recomputed each pass) */
  total: number;
  /** hotels only — sets the hotel_id FK (→ hotels.id). */
  hotelId?: string;
};

function nightsBetween(start: unknown, end: unknown): number {
  if (!start || !end) return 0;
  const a = new Date(String(start));
  const b = new Date(String(end));
  const ms = b.getTime() - a.getTime();
  if (!Number.isFinite(ms) || ms <= 0) return 0;
  return Math.round(ms / 86_400_000);
}

/* ---- Source → desired-line computations ------------------------- */

async function computeHotelDesired(
  supabase: SupabaseClient,
  tourId: string,
  workspaceId: string,
): Promise<Desired[]> {
  const { data: hotels } = await supabase
    .from('hotels')
    .select('id, name')
    .eq('tour_id', tourId)
    .eq('workspace_id', workspaceId);
  if (!hotels?.length) return [];

  const hotelIds = hotels.map((h) => h.id as string);
  const { data: rooms } = await supabase
    .from('rooms')
    .select('id, hotel_id, cost_amount, room_type')
    .eq('workspace_id', workspaceId)
    .in('hotel_id', hotelIds);

  const roomById = new Map(
    (rooms ?? []).map((r) => [r.id as string, r as { hotel_id: string; cost_amount: number | null; room_type: string | null }]),
  );
  const roomIds = (rooms ?? []).map((r) => r.id as string);

  // Distinct room types per hotel, for an informative line label
  // (OPS-04 — "Hotel — SGL, DBL" rather than a bare, unnamed-looking row).
  const typesByHotel = new Map<string, Set<string>>();
  for (const r of rooms ?? []) {
    const type = String((r as { room_type?: string | null }).room_type ?? '').trim();
    if (!type || type === '-') continue;
    const hid = (r as { hotel_id: string }).hotel_id;
    if (!typesByHotel.has(hid)) typesByHotel.set(hid, new Set());
    typesByHotel.get(hid)!.add(type);
  }

  const totalByHotel = new Map<string, number>();
  if (roomIds.length) {
    const { data: assignments } = await supabase
      .from('room_assignments')
      .select('room_id, starts_on, ends_on')
      .eq('workspace_id', workspaceId)
      .in('room_id', roomIds);

    // Collapse each room's assignments into a single date range
    // (earliest start → latest end) so a room shared by multiple people
    // is counted ONCE, not once per occupant.
    const rangeByRoom = new Map<string, { start: string; end: string }>();
    for (const a of assignments ?? []) {
      const roomId = a.room_id as string;
      const start = a.starts_on as string | null;
      const end = a.ends_on as string | null;
      if (!start || !end) continue;
      const prev = rangeByRoom.get(roomId);
      if (!prev) {
        rangeByRoom.set(roomId, { start, end });
      } else {
        rangeByRoom.set(roomId, {
          start: start < prev.start ? start : prev.start,
          end: end > prev.end ? end : prev.end,
        });
      }
    }

    // Sum cost_amount × nights once per distinct room.
    for (const [roomId, range] of rangeByRoom.entries()) {
      const room = roomById.get(roomId);
      if (!room) continue;
      const cost = Number(room.cost_amount ?? 0) * nightsBetween(range.start, range.end);
      totalByHotel.set(
        room.hotel_id,
        (totalByHotel.get(room.hotel_id) ?? 0) + cost,
      );
    }
  }

  return hotels.map((h) => {
    const hid = h.id as string;
    const name = String(h.name ?? 'Hotel');
    const types = Array.from(typesByHotel.get(hid) ?? []).sort();
    return {
      sourceId: hid,
      label: types.length ? `${name} — ${types.join(', ')}` : name,
      total: totalByHotel.get(hid) ?? 0,
      hotelId: hid,
    };
  });
}

async function computePayrollDesired(
  supabase: SupabaseClient,
  tourId: string,
  workspaceId: string,
): Promise<{ salary: Desired[]; perDiem: Desired[] }> {
  // Personnel unification — derived Salary/Per-diem lines come from every
  // roster member (rate cards linked to a live tour_personnel row). Orphan /
  // un-rostered cards don't generate budget lines.
  const { data: persons } = await supabase
    .from('personnel_rates')
    .select('id, person_name, role, order_index')
    .eq('tour_id', tourId)
    .eq('workspace_id', workspaceId)
    .not('tour_personnel_id', 'is', null);
  if (!persons?.length) return { salary: [], perDiem: [] };

  // b2 — the rate-lines source (catalog + every person's lines) for this tour.
  const rateCtx = await loadTourRateContext(supabase, tourId, workspaceId);

  // OPS-17b — compute fees from day_statuses + the rate card via the SAME
  // shared helper the payroll sheets use, instead of trusting the persisted
  // total_fee column (which can lag behind the rates after the OPS-17a math
  // fix). This guarantees the budget Salary/Per-Diem == the payroll display.
  // Day counts come from the per-week entries; the advance comes from the rate
  // card (below) — NOT entries.advance_fee — so we no longer select it.
  const { data: entries } = await supabase
    .from('payroll_entries')
    .select('personnel_id, day_statuses')
    .eq('tour_id', tourId)
    .eq('workspace_id', workspaceId);

  const countsBy = new Map<string, { show: number; offTravel: number; rehearsal: number; active: number }>();
  for (const e of entries ?? []) {
    const id = e.personnel_id as string;
    const c = countDayStatuses((e.day_statuses as Record<string, string>) ?? {});
    const acc = countsBy.get(id) ?? { show: 0, offTravel: 0, rehearsal: 0, active: 0 };
    acc.show += c.show;
    acc.offTravel += c.offTravel;
    acc.rehearsal += c.rehearsal;
    acc.active += c.active;
    countsBy.set(id, acc);
  }

  const salary: Desired[] = [];
  const perDiem: Desired[] = [];
  for (const p of persons) {
    const id = p.id as string;
    const label = p.role
      ? `${String(p.person_name)} — ${String(p.role)}`
      : String(p.person_name);
    const counts = countsBy.get(id) ?? { show: 0, offTravel: 0, rehearsal: 0, active: 0 };
    // PAY-04: rate-card advance is the single source (matches the payroll
    // displays + budget/summary routes; survives a day-status edit, which
    // zeroes the per-week entries.advance_fee). The advance rides its flat_once
    // line (a5), applied once over the aggregated counts.
    // Rates SSOT — lines come from personnel_rate_lines; the ctx carries the
    // legacy-column fallback (advance included) so this call names no columns.
    const lines = rateLinesFor(rateCtx, id);
    const { totalFee: fee, totalPerDiem: pd } = computeTotals(lines, counts);
    // One Salary line per roster member (named + costed; 0 until days set).
    salary.push({ sourceId: id, label, total: fee });
    // Phase D — Per-Diem is now SYMMETRIC with Salary: one line per roster
    // member even when their per-diem is 0 (was gated behind pd > 0, which hid
    // the whole Per-Diem section on tours with salary but no per-diem rate). A
    // £0 line adds no money, so no double-count; the section gate at
    // payroll.perDiem.length > 0 now fires whenever there are people, like Salary.
    perDiem.push({ sourceId: id, label, total: pd });
  }
  return { salary, perDiem };
}

/* ---- Section auto-create (find-or-create by name) --------------- */

async function ensureSection(
  supabase: SupabaseClient,
  tourId: string,
  workspaceId: string,
  name: string,
  /** Phase S — extra names to ADOPT if present (e.g. the singular twin), so the
   *  reconcile attaches to a template's existing section instead of creating one.
   *  The section is CREATED under `name` when none of the aliases exist. */
  aliases: string[] = [],
): Promise<string | null> {
  const { data: existing } = await supabase
    .from('budget_sections')
    .select('id, name, sort_order')
    .eq('tour_id', tourId)
    .eq('workspace_id', workspaceId);
  const matchSet = new Set([name, ...aliases].map((n) => n.toLowerCase()));
  const found = (existing ?? []).find(
    (s) => matchSet.has(String(s.name).toLowerCase()),
  );
  if (found) return found.id as string;
  const maxSort = (existing ?? []).reduce(
    (m, s) => Math.max(m, Number(s.sort_order ?? 0)),
    -1,
  );
  const { data: created } = await supabase
    .from('budget_sections')
    .insert({ tour_id: tourId, workspace_id: workspaceId, name, sort_order: maxSort + 1 })
    .select('id')
    .maybeSingle();
  return (created?.id as string | undefined) ?? null;
}

/* ---- Generic reconcile for one source_entity_type --------------- */

async function reconcileType(
  supabase: SupabaseClient,
  opts: {
    tourId: string;
    workspaceId: string;
    sourceType: string;
    sectionId: string | null;
    category: string;
    legacySection: string;
    desired: Desired[];
    setHotelId?: boolean;
    ctx: VersionCtx;
  },
): Promise<void> {
  const { tourId, workspaceId, sourceType, sectionId, category, legacySection, desired, setHotelId, ctx } =
    opts;

  const { data: existing } = await supabase
    .from('budget_line_items')
    .select('id, source_entity_id')
    .eq('workspace_id', workspaceId)
    .eq('tour_id', tourId)
    .eq('source_entity_type', sourceType);

  const desiredIds = new Set(desired.map((d) => d.sourceId));
  const idBySource = new Map<string, string>();
  for (const r of existing ?? []) {
    const sid = r.source_entity_id as string | null;
    if (sid) idBySource.set(sid, r.id as string);
    // Source entity gone. Draft → delete the derived line. Locked → the proposed
    // baseline is frozen (and deleting would cascade-fail on its immutable
    // version_lines row); just zero the ACTUAL.
    if (!sid || !desiredIds.has(sid)) {
      if (ctx.locked) {
        await supabase.from('budget_line_items')
          .update({ actual_cost: 0, updated_at: new Date().toISOString() })
          .eq('id', r.id as string).eq('workspace_id', workspaceId);
      } else {
        await supabase.from('budget_line_items')
          .delete().eq('id', r.id as string).eq('workspace_id', workspaceId);
      }
    }
  }

  for (const d of desired) {
    const existingId = idBySource.get(d.sourceId);
    if (existingId) {
      // §3a — LOCKED: actual only (never the frozen proposed/structure).
      const payload: Record<string, unknown> = {
        ...derivedUpdatePayload(ctx.locked, d, sectionId),
        updated_at: new Date().toISOString(),
      };
      if (!ctx.locked && setHotelId && d.hotelId) payload.hotel_id = d.hotelId;
      await supabase.from('budget_line_items').update(payload).eq('id', existingId).eq('workspace_id', workspaceId);
      if (!ctx.locked && ctx.draftVersionId) {
        await mirrorProposed(supabase, ctx.draftVersionId, existingId, workspaceId, sectionId, d, category);
      }
    } else {
      // New derived entity. LOCKED → actuals-only line (proposed 0, NOT in the
      // approved snapshot → shows as unbudgeted variance). DRAFT → proposed+actual.
      const { data: ins } = await supabase.from('budget_line_items').insert({
        tour_id: tourId,
        workspace_id: workspaceId,
        category,
        label: d.label,
        quantity: 1,
        proposed_cost: derivedInsertProposed(ctx.locked, d.total),
        actual_cost: d.total,
        source_entity_type: sourceType,
        source_entity_id: d.sourceId,
        section_id: sectionId,
        section: legacySection,
        order_index: 0,
        sort_order: 0,
        ...(setHotelId && d.hotelId ? { hotel_id: d.hotelId } : {}),
      }).select('id').maybeSingle();
      if (!ctx.locked && ctx.draftVersionId && ins?.id) {
        await mirrorProposed(supabase, ctx.draftVersionId, ins.id as string, workspaceId, sectionId, d, category);
      }
    }
  }
}

/** Mirror a derived line's proposed into the active DRAFT's snapshot. */
async function mirrorProposed(
  supabase: SupabaseClient,
  versionId: string,
  lineItemId: string,
  workspaceId: string,
  sectionId: string | null,
  d: Desired,
  category: string,
): Promise<void> {
  await supabase.from('budget_version_lines').upsert(
    { version_id: versionId, line_item_id: lineItemId, workspace_id: workspaceId, section_id: sectionId, label: d.label, category, proposed_cost: d.total },
    { onConflict: 'version_id,line_item_id' },
  );
}

/* ---- Public entry point ----------------------------------------- */

export async function reconcileDerivedBudgetLines(
  supabase: SupabaseClient,
  tourId: string,
  workspaceId: string,
): Promise<void> {
  try {
    // §3a — resolve the active version ONCE. Approved → feeds touch actuals only.
    const active = await resolveActiveVersion(supabase, tourId, workspaceId);
    const ctx: VersionCtx = {
      locked: active?.status === 'approved',
      draftVersionId: active?.status === 'draft' ? active.id : null,
    };

    const [hotelDesired, payroll] = await Promise.all([
      computeHotelDesired(supabase, tourId, workspaceId),
      computePayrollDesired(supabase, tourId, workspaceId),
    ]);

    if (hotelDesired.length > 0) {
      const sectionId = await ensureSection(
        supabase,
        tourId,
        workspaceId,
        SECTION_ACCOMMODATION,
      );
      await reconcileType(supabase, {
        tourId,
        workspaceId,
        sourceType: 'hotel_booking',
        sectionId,
        category: 'hotels',
        legacySection: 'hotels',
        desired: hotelDesired,
        setHotelId: true,
        ctx,
      });
    }

    if (payroll.salary.length > 0) {
      const sectionId = await ensureSection(supabase, tourId, workspaceId, SECTION_SALARY, SALARY_ALIASES);
      await reconcileType(supabase, {
        tourId,
        workspaceId,
        sourceType: 'payroll',
        sectionId,
        category: 'crew',
        legacySection: 'payroll',
        desired: payroll.salary,
        ctx,
      });
    }

    if (payroll.perDiem.length > 0) {
      const sectionId = await ensureSection(supabase, tourId, workspaceId, SECTION_PER_DIEM, PER_DIEM_ALIASES);
      await reconcileType(supabase, {
        tourId,
        workspaceId,
        sourceType: 'payroll_per_diem',
        sectionId,
        category: 'per_diems',
        legacySection: 'per_diems',
        desired: payroll.perDiem,
        ctx,
      });
    }
  } catch {
    // Never let a source hiccup break the budget page render — the grid
    // still shows whatever derived lines were last persisted.
  }
}
