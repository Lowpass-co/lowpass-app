/* ============================================
   LOWPASS — <ItemProperties> (§SP3)

   Right-hand properties panel. With an item selected: edit label,
   position, size, rotation, colour tint, lock, and delete. With
   nothing selected: edit stage settings (dimensions, grid,
   toggles, brand colour). Fuller label/grouping/shape-variant
   controls layer in as later §SP3 work.
   ============================================ */
'use client';

import { useEffect, useState } from 'react';
import { getIcon } from '@/lib/stage-plot/icons';
import { octantLabel } from '@/lib/stage-plot/geometry';
import { defaultHeightFt, readExpertDimensions, writeExpertDimensions } from '@/lib/stage-plot/item-dimensions';
import type { Channel, EditorItem, EditorPlot } from '@/lib/stage-plot/editor-types';

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8, fontSize: 'var(--lp-text-xs)', color: 'var(--lp-text-secondary)', marginBottom: 8 }}>
      <span>{label}</span>
      {children}
    </label>
  );
}

const inputStyle: React.CSSProperties = {
  width: 72, fontSize: 'var(--lp-text-xs)', padding: '4px 6px', borderRadius: 5,
  border: '1px solid var(--lp-border)', background: 'var(--lp-surface)', color: 'var(--lp-text)', textAlign: 'right',
};

/** Numeric fields render in the system numeric font so the inspector's values
 *  read as data (mono per design system), not prose. */
const numInputStyle: React.CSSProperties = { ...inputStyle, fontFamily: 'var(--lp-font-numeric)' };

function Num({ value, onChange, step = 0.5, min }: { value: number; onChange: (n: number) => void; step?: number; min?: number }) {
  return (
    <input type="number" value={value} step={step} min={min} style={numInputStyle}
      onChange={(e) => { const n = parseFloat(e.target.value); if (!Number.isNaN(n)) onChange(n); }} />
  );
}

export interface ItemPropertiesProps {
  plot: EditorPlot;
  item: EditorItem | null;
  selectedCount?: number;
  channels?: Channel[];
  onUpdateItem: (patch: Partial<EditorItem>) => void;
  onDeleteItem: () => void;
  onUpdatePlot: (patch: Partial<EditorPlot>) => void;
  /** Create a new channel-list row and return its id (§SP4 / #8). */
  onAddChannel?: (label: string) => string;
  /** §SP-FIX-3 — split a composite drum kit into individual pieces. */
  onSplitKit?: () => void;
  /** §SP-FIX-3 — recombine a split kit piece's group into the composite. */
  onCombineKit?: () => void;
  /** §SP-FIX-5 — z-order ops for the selected item. */
  onReorder?: (op: 'front' | 'back' | 'forward' | 'backward') => void;
  /** §SP-FIX-5 — rotate the selected item (riser-aware: carries gear). */
  onRotate?: (deg: number) => void;
  /** §SP-FIX-7 — pull TM details out of text annotations into the title bar. */
  onExtractTitleBar?: () => void;
  /** G2-3 — link to the paired channel-list editor. Channel NUMBERS are a derived
   *  ordinal (row-order in that list), so they stay read-only here; this jump makes
   *  reordering (the way to renumber) discoverable. */
  channelListHref?: string;
}

export function ItemProperties({ plot, item, selectedCount = 0, channels = [], onUpdateItem, onDeleteItem, onUpdatePlot, onAddChannel, onSplitKit, onCombineKit, onReorder, onRotate, onExtractTitleBar, channelListHref }: ItemPropertiesProps) {
  const [newCh, setNewCh] = useState('');
  // Expert "custom dimensions" gate (§SP-FIX-2). Off by default → items
  // lock to footprint; on → editable W×D×H. Interim home is localStorage
  // (canonical: workspace settings).
  const [expert, setExpert] = useState(false);
  // localStorage is client-only; read after mount to avoid SSR/hydration mismatch.
  // eslint-disable-next-line react-hooks/set-state-in-effect
  useEffect(() => setExpert(readExpertDimensions()), []);
  return (
    <div style={{ height: '100%', overflowY: 'auto', borderLeft: '1px solid var(--lp-border)', background: 'var(--lp-bg)', padding: 14, width: 260 }}>
      {selectedCount > 1 ? (
        <>
          <h3 style={{ fontSize: 'var(--lp-text-sm)', fontWeight: 600, color: 'var(--lp-text)', margin: '0 0 4px' }}>{selectedCount} items selected</h3>
          <p style={{ fontSize: 'var(--lp-text-2xs)', color: 'var(--lp-text-tertiary)', margin: '0 0 14px' }}>Drag to move them together.</p>
          <Row label="Rotation°"><Num value={0} step={15} onChange={(n) => onUpdateItem({ rotationDeg: n })} /></Row>
          <Row label="Tint">
            <input type="color" defaultValue="#000000" style={{ width: 40, height: 26, border: 'none', background: 'none' }} onChange={(e) => onUpdateItem({ colorTint: e.target.value })} />
          </Row>
          <button type="button" onClick={onDeleteItem} style={{ marginTop: 12, width: '100%', padding: '8px', borderRadius: 6, border: '1px solid var(--lp-border)', background: 'var(--lp-surface)', color: 'var(--lp-text-secondary)', cursor: 'pointer', fontSize: 'var(--lp-text-xs)' }}>
            Delete {selectedCount} items
          </button>
        </>
      ) : item ? (
        <>
          <h3 style={{ fontSize: 'var(--lp-text-sm)', fontWeight: 600, color: 'var(--lp-text)', margin: '0 0 4px' }}>
            {item.kind === 'text' ? 'Text box' : item.kind === 'arrow' ? 'Arrow' : getIcon(item.iconName)?.label ?? item.iconName}
          </h3>
          <p style={{ fontSize: 'var(--lp-text-2xs)', color: 'var(--lp-text-tertiary)', margin: '0 0 14px' }}>
            {item.kind === 'text' || item.kind === 'arrow' ? 'Annotation' : 'Item'}
          </p>

          {item.kind === 'text' && (
            <>
              <Row label="Text">
                <input value={item.text ?? ''} placeholder="Text" style={{ ...inputStyle, width: 130, textAlign: 'left' }}
                  onChange={(e) => onUpdateItem({ text: e.target.value })} />
              </Row>
              <Row label="Size (ft)"><Num value={item.fontSizeFt ?? 0.7} step={0.1} min={0.3} onChange={(n) => onUpdateItem({ fontSizeFt: n })} /></Row>
            </>
          )}

          {item.kind !== 'text' && item.kind !== 'arrow' && (
            <Row label="Label">
              <input value={item.label ?? ''} placeholder="—" style={{ ...inputStyle, width: 130, textAlign: 'left' }}
                onChange={(e) => onUpdateItem({ label: e.target.value })} />
            </Row>
          )}

          <Row label="X (ft)"><Num value={item.xFt} onChange={(n) => onUpdateItem({ xFt: n })} /></Row>
          <Row label="Y (ft)"><Num value={item.yFt} onChange={(n) => onUpdateItem({ yFt: n })} /></Row>

          {item.kind !== 'text' && item.kind !== 'arrow' && (
            <>
              {(onSplitKit || onCombineKit) && (
                <Row label="Display as">
                  <div style={{ display: 'flex', gap: 4 }}>
                    <button
                      type="button"
                      onClick={() => onCombineKit?.()}
                      disabled={!onCombineKit}
                      style={{ fontSize: 'var(--lp-text-2xs)', padding: '3px 8px', borderRadius: 5, border: '1px solid var(--lp-border)', background: onCombineKit ? 'var(--lp-surface)' : 'var(--lp-surface-hover)', color: 'var(--lp-text-secondary)', cursor: onCombineKit ? 'pointer' : 'default', fontWeight: onCombineKit ? 400 : 600 }}
                    >
                      Composite
                    </button>
                    <button
                      type="button"
                      onClick={() => onSplitKit?.()}
                      disabled={!onSplitKit}
                      style={{ fontSize: 'var(--lp-text-2xs)', padding: '3px 8px', borderRadius: 5, border: '1px solid var(--lp-border)', background: onSplitKit ? 'var(--lp-surface)' : 'var(--lp-surface-hover)', color: 'var(--lp-text-secondary)', cursor: onSplitKit ? 'pointer' : 'default', fontWeight: onSplitKit ? 400 : 600 }}
                    >
                      Individual
                    </button>
                  </div>
                </Row>
              )}
              {(() => {
                // §SP-FIX-2 — items lock to their real-world footprint
                // (no per-item scale). Expert mode reveals a W×D×H override.
                const icon = getIcon(item.iconName);
                const w = item.widthFt ?? icon?.footprint.width_ft ?? 1;
                const d = item.depthFt ?? icon?.footprint.depth_ft ?? 1;
                const h = item.heightFt ?? (icon ? defaultHeightFt(icon.category) : 1);
                // Risers always expose W×D×H (their dimensions are the point).
                const isRiser = item.iconName.startsWith('infra-riser-');
                if (!expert && !isRiser) {
                  return (
                    <Row label="Size (ft)">
                      <span style={{ fontSize: 'var(--lp-text-xs)', color: 'var(--lp-text)', fontFamily: 'var(--lp-font-numeric)' }}>
                        {w} × {d} <span style={{ color: 'var(--lp-text-tertiary)', fontFamily: 'var(--font-sans)' }}>· to scale</span>
                      </span>
                    </Row>
                  );
                }
                return (
                  <>
                    <Row label="Width (ft)"><Num value={w} min={0.1} onChange={(n) => onUpdateItem({ widthFt: n })} /></Row>
                    <Row label="Depth (ft)"><Num value={d} min={0.1} onChange={(n) => onUpdateItem({ depthFt: n })} /></Row>
                    <Row label="Height (ft)"><Num value={h} min={0} onChange={(n) => onUpdateItem({ heightFt: n })} /></Row>
                  </>
                );
              })()}
              <Row label="Rotation°"><Num value={item.rotationDeg ?? 0} step={15} onChange={(n) => (onRotate ? onRotate(n) : onUpdateItem({ rotationDeg: n }))} /></Row>
              {item.iconName.startsWith('infra-riser-') === false && (
                <Row label="Rotate w/ riser">
                  <input
                    type="checkbox"
                    checked={!item.decoupleRotation}
                    onChange={(e) => onUpdateItem({ decoupleRotation: e.target.checked ? undefined : true })}
                    style={{ accentColor: 'var(--lp-orange)' }}
                  />
                </Row>
              )}
              <Row label="Label">
                <select
                  value={item.labelPosition ?? 'bottom'}
                  onChange={(e) => onUpdateItem({ labelPosition: e.target.value as EditorItem['labelPosition'] })}
                  style={{ fontSize: 'var(--lp-text-xs)', padding: '4px 6px', borderRadius: 5, border: '1px solid var(--lp-border)', background: 'var(--lp-surface)', color: 'var(--lp-text)' }}
                >
                  <option value="bottom">Bottom</option>
                  <option value="top">Top</option>
                  <option value="left">Left</option>
                  <option value="right">Right</option>
                  <option value="inside">Inside</option>
                  <option value="hidden">Hidden</option>
                </select>
              </Row>
              <Row label="Label size">
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <input type="range" min={8} max={18} step={1} value={item.labelFontPx ?? 11} onChange={(e) => onUpdateItem({ labelFontPx: parseInt(e.target.value, 10) })} style={{ width: 90 }} />
                  <span style={{ fontSize: 'var(--lp-text-2xs)', color: 'var(--lp-text-tertiary)', width: 28, textAlign: 'right', fontFamily: 'var(--lp-font-numeric)' }}>{item.labelFontPx ?? 11}px</span>
                </div>
              </Row>
              <Row label="Position">
                <span style={{ fontSize: 'var(--lp-text-xs)', color: 'var(--lp-text)', fontFamily: 'var(--lp-font-numeric)' }}>
                  {octantLabel(item.xFt, item.yFt, plot.widthFt, plot.depthFt)}
                </span>
              </Row>
              {onReorder && (
                <Row label="Layer">
                  <div style={{ display: 'flex', gap: 3 }}>
                    {([['front', '⤒', 'Bring to front'], ['forward', '↑', 'Forward'], ['backward', '↓', 'Backward'], ['back', '⤓', 'Send to back']] as const).map(([op, sym, title]) => (
                      <button
                        key={op}
                        type="button"
                        title={title}
                        onClick={() => onReorder(op)}
                        style={{ width: 26, fontSize: 'var(--lp-text-xs)', padding: '3px 0', borderRadius: 5, border: '1px solid var(--lp-border)', background: 'var(--lp-surface)', color: 'var(--lp-text-secondary)', cursor: 'pointer' }}
                      >
                        {sym}
                      </button>
                    ))}
                  </div>
                </Row>
              )}
              <Row label="Custom size (expert)">
                <input
                  type="checkbox"
                  checked={expert}
                  onChange={(e) => { setExpert(e.target.checked); writeExpertDimensions(e.target.checked); }}
                  style={{ accentColor: 'var(--lp-orange)' }}
                />
              </Row>
              {/* SP-05 (A#11) — the channel-link control is always visible on item
                  select (was hidden entirely when no channel list was paired, which
                  made the whole feature undiscoverable). When no list is paired yet,
                  a prompt points at the header "Linked channel list" control. */}
              <div style={{ marginTop: 10, paddingTop: 10, borderTop: '1px solid var(--lp-border)' }}>
                <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: 8, marginBottom: 6 }}>
                  <span style={{ fontSize: 'var(--lp-text-2xs)', textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--lp-text-tertiary)' }}>
                    Channels {item.channelRowIds?.length ? `(${item.channelRowIds.length})` : ''}
                  </span>
                  {/* G2-3 — the channel number is read-only here (it's the row-order in
                      the paired list); this jump makes reordering discoverable. */}
                  {channelListHref && channels.length > 0 && (
                    <a
                      href={channelListHref}
                      title="Channel numbers follow the channel-list order — reorder there"
                      style={{ fontSize: 'var(--lp-text-2xs)', color: 'var(--lp-orange)', textDecoration: 'none', whiteSpace: 'nowrap', flexShrink: 0 }}
                    >
                      Reorder in list ↗
                    </a>
                  )}
                </div>
                {channels.length === 0 ? (
                  <div style={{ fontSize: 'var(--lp-text-2xs)', color: 'var(--lp-text-tertiary)', lineHeight: 1.4 }}>
                    No channel list linked yet. Pair one from <span style={{ color: 'var(--lp-text-secondary)' }}>Linked channel list</span> above the canvas, then link its channels to this item here.
                  </div>
                ) : (
                <>
                  {(item.channelRowIds ?? []).map((cid) => {
                    const c = channels.find((x) => x.id === cid);
                    if (!c) return null;
                    return (
                      <div key={cid} style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                        {/* VIS-SP-03 — colour STRIPE tick (channel identity). */}
                        <span style={{ width: 4, height: 14, borderRadius: 2, background: c.color || 'var(--lp-border-strong)', flexShrink: 0 }} />
                        {/* VIS-SP-05 — channel number is a DERIVED ordinal (row-order
                            position in the paired channel-list pack), not a stored
                            field, so it is shown read-only here. Changing it means
                            REORDERING the channel list (its source of truth) — a
                            cross-surface, multi-row operation that belongs to the
                            channel-list editor, not a surgical single-field write. */}
                        <span style={{ fontSize: 'var(--lp-text-xs)', color: 'var(--lp-text)', flexShrink: 0, fontFamily: 'var(--lp-font-numeric)' }}>{c.number}.</span>
                        <span style={{ flex: 1, minWidth: 0, fontSize: 'var(--lp-text-xs)', color: 'var(--lp-text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{c.label}</span>
                        <button type="button" aria-label="Unlink" onClick={() => onUpdateItem({ channelRowIds: (item.channelRowIds ?? []).filter((x) => x !== cid) })} style={{ border: 'none', background: 'none', color: 'var(--lp-text-tertiary)', cursor: 'pointer', fontSize: 14, lineHeight: 1 }}>×</button>
                      </div>
                    );
                  })}
                  {(item.channelRowIds ?? []).length === 0 && <div style={{ fontSize: 'var(--lp-text-2xs)', color: 'var(--lp-text-tertiary)', marginBottom: 4 }}>None linked.</div>}
                  <select value="" onChange={(e) => { if (e.target.value) onUpdateItem({ channelRowIds: [...(item.channelRowIds ?? []), e.target.value] }); }}
                    style={{ width: '100%', fontSize: 'var(--lp-text-xs)', padding: '4px 6px', borderRadius: 5, border: '1px solid var(--lp-border)', background: 'var(--lp-surface)', color: 'var(--lp-text)', marginTop: 4 }}>
                    <option value="">+ Link existing channel…</option>
                    {channels.filter((c) => !(item.channelRowIds ?? []).includes(c.id)).map((c) => (<option key={c.id} value={c.id}>{c.number}. {c.label}</option>))}
                  </select>
                  {onAddChannel && (
                    <div style={{ display: 'flex', gap: 4, marginTop: 4 }}>
                      <input value={newCh} onChange={(e) => setNewCh(e.target.value)} placeholder="New channel…"
                        onKeyDown={(e) => { if (e.key === 'Enter' && newCh.trim()) { const id = onAddChannel(newCh.trim()); onUpdateItem({ channelRowIds: [...(item.channelRowIds ?? []), id] }); setNewCh(''); } }}
                        style={{ flex: 1, fontSize: 'var(--lp-text-xs)', padding: '4px 6px', borderRadius: 5, border: '1px solid var(--lp-border)', background: 'var(--lp-surface)', color: 'var(--lp-text)' }} />
                      <button type="button" onClick={() => { if (newCh.trim()) { const id = onAddChannel(newCh.trim()); onUpdateItem({ channelRowIds: [...(item.channelRowIds ?? []), id] }); setNewCh(''); } }}
                        style={{ fontSize: 'var(--lp-text-xs)', padding: '4px 8px', borderRadius: 5, border: '1px solid var(--lp-border)', background: 'var(--lp-surface)', color: 'var(--lp-text-secondary)', cursor: 'pointer' }}>Add</button>
                    </div>
                  )}
                </>
                )}
              </div>
            </>
          )}

          {item.kind === 'arrow' && (
            <Row label="Thickness"><Num value={item.weight ?? 2} step={0.5} min={0.5} onChange={(n) => onUpdateItem({ weight: n })} /></Row>
          )}
          <Row label={item.kind === 'arrow' ? 'Colour' : 'Tint'}>
            <input type="color" value={item.colorTint ?? '#000000'} style={{ width: 40, height: 26, border: 'none', background: 'none' }}
              onChange={(e) => onUpdateItem({ colorTint: e.target.value })} />
          </Row>
          {item.kind !== 'text' && item.kind !== 'arrow' && (
            <Row label="Locked">
              <input type="checkbox" className="lp-checkbox" checked={Boolean(item.locked)} onChange={(e) => onUpdateItem({ locked: e.target.checked })} />
            </Row>
          )}

          <button type="button" onClick={onDeleteItem}
            style={{ marginTop: 12, width: '100%', padding: '8px', borderRadius: 6, border: '1px solid var(--lp-border)', background: 'var(--lp-surface)', color: 'var(--lp-text-secondary)', cursor: 'pointer', fontSize: 'var(--lp-text-xs)' }}>
            Delete item
          </button>
        </>
      ) : (
        <>
          <h3 style={{ fontSize: 'var(--lp-text-sm)', fontWeight: 600, color: 'var(--lp-text)', margin: '0 0 14px' }}>Stage</h3>
          <Row label="Width (ft)"><Num value={plot.widthFt} step={1} min={4} onChange={(n) => onUpdatePlot({ widthFt: n })} /></Row>
          <Row label="Depth (ft)"><Num value={plot.depthFt} step={1} min={4} onChange={(n) => onUpdatePlot({ depthFt: n })} /></Row>
          <Row label="Grid (ft)"><Num value={plot.gridSizeFt} step={0.5} min={0.5} onChange={(n) => onUpdatePlot({ gridSizeFt: n })} /></Row>
          <Row label="Show grid"><input type="checkbox" className="lp-checkbox" checked={plot.showGrid} onChange={(e) => onUpdatePlot({ showGrid: e.target.checked })} /></Row>
          <Row label="Show rulers"><input type="checkbox" className="lp-checkbox" checked={plot.showRulers} onChange={(e) => onUpdatePlot({ showRulers: e.target.checked })} /></Row>
          <Row label="Centre line"><input type="checkbox" className="lp-checkbox" checked={plot.showCenterLine} onChange={(e) => onUpdatePlot({ showCenterLine: e.target.checked })} /></Row>
          <Row label="DS centre cross"><input type="checkbox" className="lp-checkbox" checked={plot.showDsCross} onChange={(e) => onUpdatePlot({ showDsCross: e.target.checked })} /></Row>
          <Row label="Lateral markers"><input type="checkbox" className="lp-checkbox" checked={plot.showLateralMarkers} onChange={(e) => onUpdatePlot({ showLateralMarkers: e.target.checked })} /></Row>
          <Row label="Channel overlay"><input type="checkbox" className="lp-checkbox" checked={plot.showChannels} onChange={(e) => onUpdatePlot({ showChannels: e.target.checked })} /></Row>
          <Row label="Snap to grid"><input type="checkbox" className="lp-checkbox" checked={plot.snap} onChange={(e) => onUpdatePlot({ snap: e.target.checked })} /></Row>
          <Row label="Brand colour">
            <input type="color" value={plot.brandColor} style={{ width: 40, height: 26, border: 'none', background: 'none' }}
              onChange={(e) => onUpdatePlot({ brandColor: e.target.value })} />
          </Row>

          <div style={{ marginTop: 14, paddingTop: 12, borderTop: '1px solid var(--lp-border)' }}>
            <div style={{ fontSize: 'var(--lp-text-2xs)', textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--lp-text-tertiary)', marginBottom: 8 }}>Title bar</div>
            {([
              ['Subtitle', 'subtitle'],
              ['TM name', 'tmName'],
              ['TM role', 'tmRole'],
              ['TM phone', 'tmPhone'],
              ['TM email', 'tmEmail'],
              ['Version', 'versionLabel'],
            ] as const).map(([label, key]) => (
              <Row key={key} label={label}>
                <input
                  value={(plot[key] as string | undefined) ?? ''}
                  onChange={(e) => onUpdatePlot({ [key]: e.target.value } as Partial<EditorPlot>)}
                  style={{ width: 140, fontSize: 'var(--lp-text-xs)', padding: '4px 6px', borderRadius: 5, border: '1px solid var(--lp-border)', background: 'var(--lp-surface)', color: 'var(--lp-text)' }}
                />
              </Row>
            ))}
            <Row label="Logo">
              <select
                value={plot.logoPosition ?? 'top-right'}
                onChange={(e) => onUpdatePlot({ logoPosition: e.target.value as EditorPlot['logoPosition'] })}
                style={{ fontSize: 'var(--lp-text-xs)', padding: '4px 6px', borderRadius: 5, border: '1px solid var(--lp-border)', background: 'var(--lp-surface)', color: 'var(--lp-text)' }}
              >
                <option value="top-left">Top-left</option>
                <option value="top-center">Top-centre</option>
                <option value="top-right">Top-right</option>
              </select>
            </Row>
            {onExtractTitleBar && (
              <button
                type="button"
                onClick={onExtractTitleBar}
                style={{ marginTop: 6, width: '100%', padding: '6px', borderRadius: 6, border: '1px solid var(--lp-border)', background: 'var(--lp-surface)', color: 'var(--lp-text-secondary)', cursor: 'pointer', fontSize: 'var(--lp-text-2xs)' }}
              >
                Extract from text annotations
              </button>
            )}
          </div>

          <p style={{ fontSize: 'var(--lp-text-2xs)', color: 'var(--lp-text-tertiary)', marginTop: 12 }}>
            Select an item to edit its properties.
          </p>
        </>
      )}
    </div>
  );
}
