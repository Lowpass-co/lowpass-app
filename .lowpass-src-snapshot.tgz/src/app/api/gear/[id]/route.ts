import { NextResponse } from 'next/server';
import { requireWrite } from '@/lib/auth/workspace-check';
import { createServerSupabaseClient } from '@/lib/supabase-server';
import { syncDerivedBudgetRowForTour } from '@/lib/gear/deriveBudget';

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createServerSupabaseClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { data, error } = await supabase
    .from('gear')
    .select(`
      *,
      tour_gear(*)
    `)
    .eq('id', id)
    .single();
  if (error) {
    if (error.code === 'PGRST116') return NextResponse.json({ error: 'Not found' }, { status: 404 });
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
  return NextResponse.json(data);
}


export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createServerSupabaseClient();
  const auth = await requireWrite(supabase);
  if ('error' in auth) return auth.error;
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { data: profile } = await supabase.from('profiles').select('workspace_id').eq('id', user.id).single();
  if (!profile?.workspace_id) return NextResponse.json({ error: 'No workspace' }, { status: 403 });
  let body: Record<string, unknown>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 });
  }

  const payload: Record<string, unknown> = {};
  if (body.name !== undefined) payload.name = body.name;
  if (body.category !== undefined) payload.category = body.category;
  if (body.manufacturer !== undefined) payload.manufacturer = body.manufacturer;
  if (body.model !== undefined) payload.model = body.model;
  if (body.serial_number !== undefined) payload.serial_number = body.serial_number;
  if (body.ownership !== undefined) payload.ownership = body.ownership;
  if (body.owner_label !== undefined) payload.owner_label = body.owner_label;
  if (body.hire_cost_amount !== undefined) payload.hire_cost_amount = body.hire_cost_amount;
  if (body.hire_cost_currency !== undefined) payload.hire_cost_currency = body.hire_cost_currency;
  if (body.hire_cost_period !== undefined) payload.hire_cost_period = body.hire_cost_period;
  if (body.notes !== undefined) payload.notes = body.notes;
  if (body.image_url !== undefined) payload.image_url = body.image_url;
  // UX21 — link / unlink to a rental_inventory row.
  if (body.rental_inventory_id !== undefined) payload.rental_inventory_id = body.rental_inventory_id;
  // S1 — placement (space/container) + physical/carnet fields (moved up from rental_inventory).
  if (body.space_id !== undefined) payload.space_id = body.space_id;
  if (body.container_id !== undefined) payload.container_id = body.container_id;
  if (body.status !== undefined) payload.status = body.status;
  if (body.day_rate !== undefined) payload.day_rate = body.day_rate;
  if (body.day_rate_manual !== undefined) payload.day_rate_manual = body.day_rate_manual;
  if (body.purchase_cost !== undefined) payload.purchase_cost = body.purchase_cost;
  if (body.weight_kg !== undefined) payload.weight_kg = body.weight_kg;
  if (body.value_amount !== undefined) payload.value_amount = body.value_amount;
  if (body.value_currency !== undefined) payload.value_currency = body.value_currency;
  if (body.dimensions_cm !== undefined) payload.dimensions_cm = body.dimensions_cm;
  if (body.country_of_origin !== undefined) payload.country_of_origin = body.country_of_origin;
  if (body.customs_hs_code !== undefined) payload.customs_hs_code = body.customs_hs_code;
  if (body.qr_token !== undefined) payload.qr_token = body.qr_token;

  if (Object.keys(payload).length > 0) {
    const { error: updateErr } = await supabase.from('gear').update(payload).eq('id', id);
    if (updateErr) return NextResponse.json({ error: updateErr.message }, { status: 500 });
  }

  const tourGear = body.tour_gear as
    | Array<{
        id?: string;
        tour_id: string;
        tour_ownership?: string | null;
        tour_hire_cost_amount?: number | null;
        tour_hire_cost_currency?: string | null;
        tour_hire_cost_period?: string | null;
        starts_on?: string | null;
        ends_on?: string | null;
        quantity?: number;
        notes?: string | null;
      }>
    | undefined;
  if (tourGear && Array.isArray(tourGear)) {
    for (const tg of tourGear) {
      if (!tg.tour_id) continue;
      const upsertPayload = {
        workspace_id: profile.workspace_id,
        tour_id: tg.tour_id,
        gear_id: id,
        tour_ownership: tg.tour_ownership ?? null,
        tour_hire_cost_amount: tg.tour_hire_cost_amount ?? null,
        tour_hire_cost_currency: tg.tour_hire_cost_currency ?? null,
        tour_hire_cost_period: tg.tour_hire_cost_period ?? null,
        starts_on: tg.starts_on ?? null,
        ends_on: tg.ends_on ?? null,
        quantity: tg.quantity ?? 1,
        notes: tg.notes ?? null,
      };
      await supabase.from('tour_gear').upsert(upsertPayload, { onConflict: 'tour_id,gear_id' });
    }
  }

  const syncTourIds = Array.isArray(body.sync_tour_ids)
    ? (body.sync_tour_ids as unknown[]).filter((v): v is string => typeof v === 'string')
    : [];
  const syncTourId = typeof body.sync_tour_id === 'string' ? body.sync_tour_id : null;
  const targets = new Set<string>(syncTourIds);
  if (syncTourId) targets.add(syncTourId);

  if (targets.size > 0) {
    for (const tourId of targets) {
      await syncDerivedBudgetRowForTour(supabase, profile.workspace_id, id, tourId);
    }
  }

  const { data, error } = await supabase
    .from('gear')
    .select(`
      *,
      tour_gear(*)
    `)
    .eq('id', id)
    .single();
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json(data);
}
