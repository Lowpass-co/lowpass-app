/* ============================================
   LOWPASS — Operations · Routing (Sprint 9 §5)

   /operations/[tourId]/routing — replaces the placeholder.
   Renders <RoutingEditor> wrapped in:
     - the grouped top nav (Routing active) + Stage-B group sub-nav
       from the operations layout (Routing is a single-page landing,
       so no second bar shows here).
     - "Last edit" line from audit_log (Sprint 10's audit surface
       will replace this with a richer view).
     - 403 panel when the caller has no read access for
       operations.routing.

   Permission gate is page-level (TS port of can_access). RLS at
   the DB layer is the second line of defense — even if this
   page renders erroneously, a readonly caller without a grant
   still hits get_my_workspace_id and the underlying tables'
   policies.
   ============================================ */

import { notFound, redirect } from 'next/navigation';
import Link from 'next/link';
import { createServerSupabaseClient } from '@/lib/supabase-server';
import { RoutingEditor } from '@/components/routing/RoutingEditor';
import { TourFingerprint, type FingerprintDay } from '@/components/tour/TourFingerprint';
import { RoutingStatLine } from '@/components/operations/RoutingReadinessRail';
import { PageTitle } from '@/components/ui/PageHeader';
import {
  getOperationsReadiness,
  type OperationsReadiness,
} from '@/server/operations/getOperationsReadiness';
import {
  getRoutingDayStatus,
  type RoutingStatusByDate,
} from '@/server/operations/getRoutingDayStatus';
import {
  getActiveMembership,
  fetchActiveGrants,
  canAccess,
} from '@/lib/permissions/server';

export const dynamic = 'force-dynamic';

interface OperationsRoutingPageProps {
  params: Promise<{ tourId: string }>;
}

/* Sprint 9 §14.11 — SUB_NAV moved to layout. */

function relativeTime(iso: string | null): string {
  if (!iso) return '—';
  const d = new Date(iso);
  const diff = Date.now() - d.getTime();
  const m = Math.floor(diff / 60000);
  const h = Math.floor(diff / 3600000);
  const day = Math.floor(diff / 86400000);
  if (m < 1) return 'just now';
  if (m < 60) return `${m}m ago`;
  if (h < 24) return `${h}h ago`;
  if (day < 30) return `${day}d ago`;
  return d.toLocaleDateString();
}

export default async function OperationsTourRoutingPage({
  params,
}: OperationsRoutingPageProps) {
  const { tourId } = await params;
  const supabase = await createServerSupabaseClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) {
    redirect(`/login?next=/operations/${tourId}/routing`);
  }

  const membership = await getActiveMembership(supabase, user.id);
  if (!membership) {
    return <NoWorkspacePanel />;
  }

  const grants = await fetchActiveGrants(supabase, membership, user.id);

  const canRead = canAccess(membership, grants, 'page', 'operations.routing', 'read');
  const canWrite = canAccess(membership, grants, 'page', 'operations.routing', 'write');

  const { data: tour } = await supabase
    .from('tours')
    .select('id, name, start_date, end_date, custom_day_types')
    .eq('id', tourId)
    .maybeSingle();
  if (!tour) notFound();
  const tourRow = tour as {
    id: string;
    name: string;
    start_date: string | null;
    end_date: string | null;
    custom_day_types: string[] | null;
  };

  // "Last edit" — derived from audit_log. Pre-Sprint-9 edits
  // weren't audited so existing tours show no last-edit line
  // until first save under this version.
  let lastEdit: { actor_name: string | null; created_at: string } | null = null;
  // Hero-scale <TourFingerprint> data — date + day_type only (no venue read),
  // reusing this routing fetch. Highlight the next upcoming show.
  let fingerprintDays: FingerprintDay[] = [];
  let nextShowDate: string | null = null;
  // R1 — the fingerprint outlines the CURRENT day (today) when it's a tour day,
  // else falls back to the next upcoming show.
  let highlightDate: string | null = null;
  // TR-02 — readiness rail data (Shows / Crew / Conflicts / Pending), shared
  // with the relocated /summary surface via getOperationsReadiness.
  let readiness: OperationsReadiness | null = null;
  // R2 — per-date status dots (advance · hotel · crew), derived once here (one
  // batch, no per-cell queries) and handed to the ledger.
  let statusByDate: RoutingStatusByDate = {};
  // F-3(b) — the ledger's first-paint payload, from the same query as above.
  type LedgerSeedRows = React.ComponentProps<typeof RoutingEditor>['initialRows'];
  let ledgerRows: LedgerSeedRows = undefined;
  if (canRead) {
    [readiness, statusByDate] = await Promise.all([
      getOperationsReadiness(supabase, {
        tourId,
        workspaceId: membership.workspace_id,
        tourStartDate: tourRow.start_date,
        tourEndDate: tourRow.end_date,
      }),
      getRoutingDayStatus(supabase, { tourId }),
    ]);
    // F-3(b) — ONE server query now serves three consumers: the fingerprint, the
    // ledger's first paint, and the last-edit lookup. It used to select only
    // `id, date, day_type` for the fingerprint, and RoutingEditor then refetched
    // the SAME rows over the API before it could render — the cold-load hang.
    const { data: routingRows } = await supabase
      .from('routing')
      .select(
        'id, date, day_type, city, country, address, venue_name, venue_website, venue_phone, venue_capacity, notes, latitude, longitude, transport_to_next, canonical_venue_id',
      )
      .eq('tour_id', tourId)
      .order('date', { ascending: true });
    const rows = (routingRows ?? []) as Array<{ id: string; date: string; day_type: string | null }>;
    ledgerRows = (routingRows ?? []) as LedgerSeedRows;
    const ids = rows.map((r) => r.id);
    fingerprintDays = rows.map((r) => ({ date: r.date, dayType: r.day_type ?? 'off', routingId: r.id }));
    const todayIso = new Date().toISOString().slice(0, 10);
    nextShowDate =
      fingerprintDays.find((d) => {
        const first = d.dayType.split(',')[0]?.trim().toLowerCase();
        return (first === 'show' || first === 'festival') && d.date >= todayIso;
      })?.date ?? null;
    highlightDate = fingerprintDays.some((d) => d.date.slice(0, 10) === todayIso) ? todayIso : nextShowDate;
    if (ids.length > 0) {
      const { data: audit } = await supabase
        .from('audit_log')
        .select('actor_user_id, created_at')
        .eq('entity_type', 'routing')
        .in('entity_id', ids)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      if (audit) {
        const a = audit as { actor_user_id: string | null; created_at: string };
        let actor_name: string | null = null;
        if (a.actor_user_id) {
          const { data: profile } = await supabase
            .from('profiles')
            .select('name')
            .eq('id', a.actor_user_id)
            .maybeSingle();
          actor_name = (profile as { name?: string | null } | null)?.name ?? null;
        }
        lastEdit = { actor_name, created_at: a.created_at };
      }
    }
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: 0 }}>
      {/* Sprint 9 §14.11 — sub-nav now mounted by the layout. */}
      <div
        className="mx-auto w-full"
        style={{
          flex: 1,
          minWidth: 0,
          padding: 'var(--lp-space-4)',
        }}
      >
        <header
          className="flex flex-wrap items-baseline"
          style={{
            gap: 'var(--lp-space-3)',
            marginBottom: 'var(--lp-space-3)',
          }}
        >
          <PageTitle style={{ margin: 0 }}>Routing</PageTitle>
          {/* R1 — the five KPI boxes collapse into ONE mono stat line, inline
              with the condensed title (mock header row). */}
          {canRead && readiness ? (
            <RoutingStatLine tourId={tourId} dayCount={fingerprintDays.length} readiness={readiness} />
          ) : null}
          {lastEdit ? (
            <span
              style={{
                marginLeft: 'auto',
                fontSize: 'var(--lp-text-xs)',
                color: 'var(--lp-text-tertiary)',
              }}
            >
              Last edit: {relativeTime(lastEdit.created_at)}
              {lastEdit.actor_name ? ` by ${lastEdit.actor_name}` : ''}
            </span>
          ) : null}
        </header>

        {/* §C4 — full-width hero day-strip: the tour at a glance above the grid,
            spanning the page width (fill) with week-commencing markers. */}
        {canRead && fingerprintDays.length > 0 ? (
          <div style={{ marginBottom: 'var(--lp-space-4)' }}>
            <TourFingerprint
              days={fingerprintDays}
              size="hero"
              fill
              weekMarkers
              highlightDate={highlightDate}
              ariaLabel={`${tourRow.name} day strip`}
            />
          </div>
        ) : null}

        {!canRead ? (
          <NoAccessPanel resource="Routing" />
        ) : (
          <RoutingEditor
            tourId={tourId}
            startDate={tourRow.start_date ?? ''}
            endDate={tourRow.end_date ?? ''}
            initialCustomDayTypes={tourRow.custom_day_types ?? []}
            readOnly={!canWrite}
            statusByDate={statusByDate}
            initialRows={ledgerRows}
          />
        )}
      </div>
    </div>
  );
}

function NoAccessPanel({ resource }: { resource: string }) {
  return (
    <div
      role="alert"
      style={{
        padding: 'var(--lp-space-4)',
        background: 'var(--lp-panel)',
        border: '1px solid var(--lp-border-strong)',
        borderRadius: 'var(--lp-radius-md)',
      }}
    >
      <h2
        style={{
          margin: 0,
          fontSize: 'var(--lp-text-base)',
          fontWeight: 'var(--lp-weight-semibold)',
          color: 'var(--lp-text)',
        }}
      >
        {resource} is restricted
      </h2>
      <p
        style={{
          marginTop: 'var(--lp-space-1)',
          fontSize: 'var(--lp-text-sm)',
          color: 'var(--lp-text-secondary)',
        }}
      >
        You don&apos;t have read access for this page in the active workspace.
        Ask an admin to grant <code>operations.routing</code> in{' '}
        <Link
          href="/settings/members"
          style={{ color: 'var(--color-lp-orange)', textDecoration: 'underline' }}
        >
          /settings/members
        </Link>
        .
      </p>
    </div>
  );
}

function NoWorkspacePanel() {
  return (
    <div
      style={{
        padding: 'var(--lp-space-6)',
        textAlign: 'center',
        color: 'var(--lp-text-secondary)',
      }}
    >
      <h2
        style={{
          margin: 0,
          fontSize: 'var(--lp-text-base)',
          fontWeight: 'var(--lp-weight-semibold)',
          color: 'var(--lp-text)',
        }}
      >
        No active workspace
      </h2>
      <p
        style={{
          marginTop: 'var(--lp-space-1)',
          fontSize: 'var(--lp-text-sm)',
        }}
      >
        Your account isn&apos;t a member of any workspace, or the active
        workspace has been removed. Contact your admin.
      </p>
    </div>
  );
}
