# Smoke tests — the canonical shell (S-1 → S-5)

Format per `docs/smoke-tests/README.md`. IDs are stable; add new ones as banks land.

**As of S-3b: EVERY scope is on the canonical shell.** Tour, artist, workspace
and You — every authenticated URL outside `/admin` and `/m`. The two-bar nav,
`ProductShell`, `WorkspaceTopBar` and `WorkspaceTabs` are deleted.

The authoritative answer is `isShelledPath()` in `src/lib/nav/ia.ts`; the list
above is a description of it, not a second source of truth.

Grab a tour id from any tour URL you already have open and substitute it for
`[tourId]` below.

---

## Still to do — S-1 (nobody has checked these)

- [ ] **SHELL-05 — Collapse persists across a reload.** On Routing, click
  **Collapse** at the bottom of the rail → it shrinks to icons. **Reload.** Still
  collapsed. Expand it. **Reload.** Still expanded.
  *Why it matters: the preference is per-user in localStorage; if it doesn't
  survive a reload it isn't a preference, it's a toggle.*

- [ ] **SHELL-06 — Collapsed icons are identifiable.** With the rail collapsed,
  hover each icon → a tooltip names it (Routing, Day sheets, Advance, Crew,
  Rooming, Travel, Files).
  *A 52px icon strip with no tooltips is a guessing game.*

- [ ] **SHELL-07 — Unbuilt pages read as gaps, not as bugs.** **Travel** appears
  in the rail, dimmed, not clickable, and hovering says "Travel — no page yet".
  *IA_CANONICAL's point: these are missing pages, not missing nav.*

- [ ] **SHELL-08 — The back button walks scope changes.** From Routing: click
  **Money** (lands on Budget summary, old chrome), then **browser Back**. You are
  on Routing with the shell, Tour mode active, rail intact.

- [ ] **SHELL-09 — The ↑ link goes up a level.** Top of the rail shows
  **↑ Artist**. Click it → the artist page (old chrome for now — that's S-3a).

- [ ] **SHELL-10 — Deep link, cold.** Open a **new private window**, log in, and
  paste `/operations/[tourId]/routing` directly. Artist and tour are populated in
  the top bar — no "Pick an artist…" left sitting there, no blank.
  *Known cosmetic issue: the picker may flash "Pick an artist…" for one frame
  before settling. That's logged and fixed in S-2a. What this test is checking is
  that it RESOLVES, not that the flash is gone.*

- [ ] **SHELL-11 — Nothing else regressed.** Load each of these and confirm the
  page renders with its OLD chrome and no error boundary:
  `/budget/[tourId]` · `/operations/[tourId]/personnel` ·
  `/operations/[tourId]/day` · `/operations/[tourId]/rooming` ·
  `/advance/[tourId]` · `/artists` · `/venues` · `/settings`

- [ ] **SHELL-13 — A click is acknowledged before the page arrives.** On Routing,
  click **Crew** in the rail. *Immediately* — before the new page paints — the row
  takes the orange active marker and its icon becomes a spinner. Same for the
  **Money** pill (it tints and its icon spins) and for **↑ Artist**.
  *Why it matters: a route change can take a second on a cold lambda, and for
  that second an app that heard the click looks exactly like one that didn't —
  so people click again.*
  *Note: on a warm, prefetched route the page can arrive in well under a frame,
  so you may see nothing. That's correct. To see it, hard-reload first, or click
  a mode you haven't visited this session.*

- [ ] **SHELL-12 — Screenshots** at **1440** and **1920**, for the record:
  Routing with the shell, expanded rail; Routing with the rail collapsed.
  *(The other three scopes aren't migrated yet — their screenshots belong to
  S-3a/S-3b.)*

---

## Still to do — S-2a (Tour mode)

- [ ] **SHELL-14 — Every Tour-mode surface renders with the new shell.** Load
  each and confirm the page body appears with the top bar + left rail, no error
  boundary, and the RIGHT rail item lit:
  `/operations/[tourId]/routing` (Routing) · `/operations/[tourId]/day` (Day
  sheets) · `/operations/[tourId]/personnel` (Crew) ·
  `/operations/[tourId]/rooming` (Rooming) · `/operations/[tourId]/files`
  (Files) · `/advance/[tourId]` (Advance).
  *This is the bank. If one of these 500s it's the same RSC class as S-1 —
  see "If something is broken" below.*

- [ ] **SHELL-15 — The old chrome is GONE on those pages, not doubled.** No
  two-bar product nav, no Operations sub-nav strip, no artist/tour identity
  band above the content. One nav, not two.

- [ ] **SHELL-16 — The day rail and the app rail coexist.** On
  `/operations/[tourId]/rooming` and on a day page
  (`/operations/[tourId]/day/[routingId]`), the app rail starts **collapsed**
  and the day rail keeps its full width. On **Routing**, the app rail starts
  **expanded** — Routing has no day rail.
  *This is the correction from your first walk: S-1 collapsed it on Routing,
  which was my mistake.*

- [ ] **SHELL-17 — The picker no longer flashes.** Hard-reload
  `/operations/[tourId]/rooming`. The artist and tour names are in the top bar
  **in the first paint** — no "Pick an artist…" beat.
  *The layout knew the artist server-side all along; it was waiting for a client
  effect to tell it.*

- [ ] **SHELL-18 — Resume still knows where you were.** Open
  `/operations/[tourId]/rooming`, go to `/artists`, and use the Resume / pick-up
  card for that tour. It should return you to Operations, not Budget.
  *ProductShell used to record this; the new shell has to keep doing it.*

- [ ] ~~**SHELL-19 — Production is untouched.**~~ **Retired at S-2c** — nothing
  tour-scoped is on old chrome any more, so there is no boundary left inside the
  tour to check. The boundary is now tour-vs-artist, covered by SHELL-27.

---

## Still to do — S-2b (Money mode)

- [ ] **SHELL-20 — Money mode renders, and the pill agrees.** Load
  `/budget/[tourId]?tab=summary` · `?tab=budget` · `?tab=income` ·
  `?tab=receipts` · `?tab=settings`, then `/budget/[tourId]/settlement` and
  `/operations/[tourId]/payroll`. Each shows the shell with the **MONEY** pill
  lit and the matching rail item active — including Payroll, which lives at an
  `/operations/…` URL but belongs to Money.

- [ ] **SHELL-21 — The budget tabs are in ONE place now.** On any budget tab,
  the old Summary/Expenses/Income/Receipts/Settings strip is **gone** from the
  band; the rail carries them. The band keeps the **version selector**, the
  **density toggle** and **Export** — check all three are still there and still
  work.

- [ ] **SHELL-22 — The Receipts count survived the move.** With at least one
  receipt missing fields, the rail's **Receipts** item shows the count. Fix the
  last one and the number **disappears entirely** — it should not sit at "0".
  *That badge used to live on the tab band. It's the one number on that bar
  anyone acts on, so it had to move rather than quietly vanish.*

- [ ] **SHELL-23 — Money still adds up.** On `/budget/[tourId]` confirm the
  grid, burn bar and totals read the same as before the chrome changed, and that
  `/budget/[tourId]/settlement` still opens and totals.
  *Chrome-only bank — if a number moved, that's the finding.*

---

## Still to do — the S-2b fixpack + S-2c (Production)

- [ ] **SHELL-24 — Rooming keeps its rail expanded.** Load
  `/operations/[tourId]/rooming`. The app rail is **expanded** on arrival, in
  all three views (Matrix / Cards / Nights).
  *Your finding: only Cards renders a day rail, and the view defaults to Matrix,
  so collapsing here was wrong on every arrival. In Cards you now get two rails
  — collapse it once and the choice persists.*

- [ ] **SHELL-25 — Labor calls lights Day sheets.** Open a labor call
  (`/operations/[tourId]/labor`). The rail highlights **Day sheets**, its
  parent. Nothing lit at all reads as broken.

- [ ] **SHELL-26 — Production mode renders.** `/operations/[tourId]/hire`
  (Assets) · `/channel-list` · `/stage-plot` · `/riders` · a rider pack
  (`/riders/[id]`). Shell present, **PRODUCTION** pill lit, right rail item
  active, no old two-bar nav.
  On the **rider pack** specifically: it has its own 280px sidebar, so the app
  rail should start **collapsed** there — and only there, not on the pack list.

- [ ] **SHELL-27 — The boundary moved up a level.** `/artists` ·
  `/artists/[id]` · `/venues` · `/settings` still render their OLD chrome with
  no error. That's the S-3 line now; nothing tour-scoped is left behind it.

- [ ] **SHELL-28 — "Reports & workbook", not "Settings".** The Money rail's last
  Plan-side item reads **Reports & workbook** and lands on the same page the old
  Settings tab did. The URL is still `?tab=settings` — bookmarks intact.

---

## Still to do — S-2d (retire the old tour chrome)

- [ ] **SHELL-29 — The tour still works with the old chrome deleted.** Walk one
  surface per mode and confirm no error boundary:
  `/operations/[tourId]/routing` · `/operations/[tourId]/payroll` ·
  `/budget/[tourId]` · `/advance/[tourId]` · `/operations/[tourId]/channel-list`.
  *Three layouts lost a whole branch; this is the "did anything depend on it"
  check.*

- [ ] **SHELL-30 — The ARTIST and workspace tiers are untouched.**
  `/artists/[id]` · `/artists/[id]/riders` · `/artists/[id]/edit` · `/settings` ·
  `/settings/members` · `/venues` · `/bugs` · `/operations` (no tour id) ·
  `/budget` (no tour id). All still on the two-bar chrome, all still render.
  *These share `ProductShell` with the tour layouts, so this is the test that
  says the deletion stopped where it should have.*

- [ ] **SHELL-31 — Patch is gone from the rail, and still works.** The
  Production rail no longer lists **Patch**. Open
  `/operations/[tourId]/channel-list` and hit the **PATCH** toggle — the patch
  matrix still opens.
  *It was never a page; greying it claimed working software was missing.*

---

## Still to do — S-3a (artist scope)

- [ ] **SHELL-32 — Every artist surface renders, with the right item lit.**
  `/artists/[id]` (Overview) · `/artists/[id]/production` (Overview) ·
  `/artists/[id]/edit` (Overview) · `/artists/[id]/riders` (Riders & specs) ·
  `/artists/[id]/channel-lists` (Riders & specs) · `/artists/[id]/stage-plots`
  (Riders & specs) · `/artists/[id]/files` (Documents) ·
  `/artists/[id]/financials` (Overview).
  *Three separate chrome wrappers collapsed into one layout here, and Edit had
  its own — this is the "did they all land in the same place" check.*

- [ ] **SHELL-33 — NO mode pill at artist scope.** Money and Production are
  properties of a tour. The top bar shows workspace · picker · avatar, and the
  rail head reads **ARTIST**. The ↑ link goes to **Workspace**.

- [ ] **SHELL-34 — The library is reachable from the rail.** Before this bank
  nothing outside the artist tree linked to riders / channel-lists /
  stage-plots / files at all — they were reached only from inside. Click each
  from the rail and confirm it lands.

- [ ] **SHELL-35 — Tours is gone from the rail, and nothing was lost.** The
  artist rail has **Overview**, not Overview *and* Tours. `/artists/[id]` still
  shows the hero + tour list, and the hero's own Tours / Production / Business
  tabs still work.
  *They were one page all along; a second rail item on the same URL could never
  light.*

- [ ] **SHELL-36 — The picker knows the artist immediately.** Hard-reload
  `/artists/[id]/riders`. The artist name is in the top bar on first paint.
  *No layout queries for it — it comes out of the artist list the picker was
  already fetching.*

- [ ] **SHELL-37 — Workspace and You are untouched.** `/artists` (the list) ·
  `/personnel` · `/assets` · `/venues` · `/settings` · `/settings/members` ·
  `/profile` · `/bugs` · `/operations` and `/budget` with no tour id. All still
  two-bar chrome, all still render. That is the S-3b line.

---

## Still to do — S-4a (live bugs)

- [ ] **SHELL-38 — Stale `/library/*` links land somewhere, not on an error.**
  Paste each into the address bar:
  `/library/deal-memos/anything` · `/library/templates/anything` ·
  `/library/rider-packs/anything` → all three should land on **home**, via the
  existing catch-all. `/library/gear` → **/equipment**. `/library/venues` →
  **/venues**.
  *Before: the first four 404'd. A redirect into a 404 is worse than no
  redirect — you can't tell whether the page died or the redirect lied.*

- [ ] **SHELL-39 — The Business tab still can't be clicked.** On `/artists/[id]`,
  the hero's **Business** tab shows a lock, does nothing on click, and explains
  itself on hover. Tours and Production still switch.
  *No code changed here — this is confirming the thing I claimed was already
  safe actually is.*

---

## Still to do — S-4b (orphans and ex-stubs)

- [ ] **SHELL-40 — The four ex-stubs still redirect, AND their tails now work.**
  Bare: `/rooming` · `/calendar` · `/rider-packs` → **/artists**.
  `/account/rental` → **/equipment**.
  Tails (these 404'd before): `/rooming/x` · `/calendar/x` →
  **/artists**; `/account/rental/some-id` → **/equipment**.

- [ ] **SHELL-41 — The rider pack editor still opens. THIS IS THE ONE THAT
  MATTERS.** From `/advance/[tourId]/[routingId]/share`, click a rider or stage
  plot's **edit** link → `/rider-packs/[id]` opens the editor. Also from
  `/artists/[id]/riders`, click a row.
  *`/rider-packs` is an exact-match redirect for this reason. If it had been a
  tail glob, every one of these would land on /artists instead.*

- [ ] **SHELL-42 — The deleted routes are gone, and nothing links to them.**
  `/gear` and `/artists/[id]/financials` should 404. Then walk
  `/artists/[id]` and `/operations/[tourId]/hire` and confirm nothing offers a
  link to either — the gear LIBRARY still renders inside Assets/hire, which is
  the component, not the deleted page.

---

## Still to do — S-4c (the legacy /tours tree)

- [ ] **SHELL-43 — Every `/tours/…` URL still lands. Test in an INCOGNITO
  window** — 301s cache hard, so a stale browser will lie to you about this.

  Substitute a real tour id. Bare paths (these worked before — confirming
  nothing regressed):

  | paste this | should land on |
  |---|---|
  | `/tours` | `/artists` |
  | `/tours/<id>` | `/operations/<id>/routing` |
  | `/tours/<id>/routing` | `/operations/<id>/routing` |
  | `/tours/<id>/personnel` | `/operations/<id>/personnel` |
  | `/tours/<id>/budget` | `/budget/<id>` |
  | `/tours/<id>/budget/settlement` | `/budget/<id>/settlement` |

  **Sub-paths — these 404'd before this bank:**

  | paste this | should land on |
  |---|---|
  | `/tours/<id>/routing/anything` | `/operations/<id>/routing` |
  | `/tours/<id>/budget/anything-else` | `/operations/<id>/routing` |
  | `/tours/<id>/personnel/anything` | `/operations/<id>/routing` |
  | `/tours/<id>/day/some-routing-id` | `/operations/<id>/routing` |
  | `/tours/<id>/rider-packs/<packId>` | `/operations/<id>/riders/<packId>` |
  | `/tours/<id>/tour-wide` | `/operations/<id>/routing` |

- [ ] **SHELL-44 — The five shared components survived.** Load
  `/operations/[tourId]/edit` (TourEditForm) · `/operations/[tourId]/files` and
  `/artists/[id]/files` (TourFilesClient) · `/operations/[tourId]/riders`
  (RiderPacksTourClient) · `/budget/[tourId]?tab=summary` (TourPhaseContextStrip).
  *These live in `src/components/tours/`. Deleting that folder wholesale — which
  "delete the legacy tree" invites — would have taken all five down.*

---

## Still to do — S-4d (shell-v1)

- [ ] **SHELL-45 — Everything still standing on shell-v1 still stands.**
  `/budget` (NO tour id) · `/profile` · `/admin` · `/admin/ai-usage` ·
  `/admin/design-tokens` · `/admin/shell-playground` ·
  `/admin/data-table-playground` · `/admin/spreadsheet-playground`.
  All render, none 500.

- [ ] **SHELL-46 — A slide-over still opens.** Any one will do — a budget line,
  a person, a venue. Open it, edit something, close it.
  *`SlideOver` lives in `src/components/shell/`, so it looks like shell-v1. It
  has 25 importers and is the canonical primitive. This test exists because
  "retire shell-v1" read literally would delete it.*

- [ ] **SHELL-47 — The avatar menu still works.** Top right of the NEW shell, on
  any tour page. Open it, check the entries, sign-out link present.
  *`AccountAvatar` is a shell-v1 component rendered inside shell-v3.*

- [ ] **SHELL-48 — The rider pack editor still opens.** `/rider-packs/[id]`, via
  the Advance share surface. *It mounts `builderAppPageShell` — shell-v1. Second
  bank running where this component is the thing at risk.*

---

## Still to do — P-1 (the rail's access filter)

> **SHELL-49 CANNOT BE RUN AS AN ADMIN.** `canAccess` returns true
> unconditionally for admin and manager, so the filter is a no-op by
> construction in an admin session. Every previous walk in this pass was run as
> an admin, which is exactly why two permission-scoped surfaces looked like dead
> code. This needs a **second, readonly account**.

- [ ] **SHELL-49 — A restricted member sees a shorter rail.**
  **Setup:** in `/settings/members`, add or pick a member with role
  **readonly**. Grant them read on `operations.routing` and
  `operations.personnel` and nothing else. Sign in as them (separate browser
  profile / private window).

  1. Open `/operations/[tourId]/routing`. The Tour rail should show **Routing**
     and **Crew** — and **not** Rooming or Files. Day sheets, Travel and Advance
     may still show; Day sheets has no catalogue entry, so it is ungated by
     design.
  2. Switch to **Money**. **Payroll must NOT be listed.** This is the acceptance
     test — it is the item the retired sub-nav used to hide, and the reason P-1
     exists.
  3. Switch to **Production**. Channel list, Stage plot and Riders should all be
     absent; Assets may remain (no catalogue entry).
  4. **No empty headings.** If a group's items are all hidden, the heading goes
     too — you should never see a lone "Settle & pay" with nothing under it.
  5. Now grant that member `operations.rooming`, reload: **Rooming appears.**
     Revoke it, reload: it goes. That round-trip is what proves the allow-list
     tracks the real grants rather than a cached guess.

- [ ] **SHELL-50 — Nothing changed for you.** Back in your own admin session,
  walk one surface per mode (`/routing`, `/budget/[tourId]`,
  `/operations/[tourId]/channel-list`). Every rail item still present.
  *Admin/manager skip the grants query entirely, so this should be identical to
  S-3a — including load time.*

- [ ] **SHELL-51 — The permission-fallback landing still works.** As the
  restricted member from SHELL-49, **revoke `operations.routing`** (leaving
  personnel), then open `/operations/[tourId]` bare. You should land on
  `/summary` and see a page, not a 404.
  *This is the surface S-4b refused to delete. Whether /summary is the RIGHT
  landing is the open question — report what it actually feels like to be that
  user, because nobody ever has been.*

---

## Still to do — F-1 (hygiene)

- [ ] **SHELL-52 — Slide-overs still work, everywhere.** The primitive moved
  file, so this is the blast-radius check for 26 callers. Open and close one of
  each: a **budget line** detail · a **person** (Crew) · a **venue** · a
  **gear** item · the **tour edit** slide-over (with its date-window warning) ·
  a **rider pack** panel.
  *Nothing about the component changed — only its path. A miss here would be an
  import that didn't get rewritten, and it would show as a blank panel or a
  build-time error, not a subtle one.*

- [ ] **SHELL-53 — The avatar menu renders on BOTH shells.** Top-right on
  `/operations/[tourId]/routing` (shell-v3) **and** on `/admin` (shell-v1).
  Open it, check the entries, sign-out link present.
  *AccountAvatar moved too, and it's the one component both shells share.*

- [ ] **SHELL-54 — Tour slide-over links land in one hop.** Open a tour
  slide-over (⌘K → a tour, or an entity chip). **Open tour** → Routing.
  **Overview** → Routing. **Personnel** → operations personnel. **Open budget**
  → that tour's budget.
  *These went through a 301 before. Watch for a visible double-navigation.*

---

## Still to do — P0-A (write authorization)

> **This is the bank the beta is blocked on.** The acceptance test is a real
> readonly session refused **by the API**. A hidden button proves nothing — the
> endpoint is what was open.

- [ ] **P0-01 — The readonly account cannot edit a global venue.** Signed in as
  the readonly member (the same account that created an artist):
  1. Open `/venues`, pick any venue, change its name, save.
  2. **Expect a 403** and an error, not a save.
  3. **Then check it in the network tab**, not just the UI — the request must
     come back `403 Forbidden — your role cannot make this change.` If the UI
     shows an error but the PATCH returned 200, the write landed and the toast
     is lying.
  4. Reload as admin and confirm the venue name is **unchanged**.

- [ ] **P0-02 — Admin and manager can still edit a venue.** Same flow as admin:
  save succeeds, name changes, and a routing row referencing that venue shows
  the corrected name.
  *The guard must refuse the right people and only them — a fix that breaks
  venue correction for admins is not a fix.*

- [ ] **P0-03 — Venue search and read are untouched.** As readonly: `/venues`
  lists, the venue autocomplete on a routing row still returns hits, and the
  venue slide-over still opens. Reads were never the finding.

**Still open after this bank** — `POST /api/artists` and ~165 other mutating
handlers are unchanged. P0-A closed the cross-tenant one. **Do not read a green
P0-01 as "readonly is now safe."**

---

## Still to do — Equipment quote (items 1–4)

> **Migration 253 is PASTE-GATED.** Until Adam pastes it, `display_currency`,
> `fx_rate` and `fx_rate_at` do not exist and the switcher cannot persist. The
> code treats a missing currency as USD, so the page still works — it just
> can't change currency. Paste first, then run EQ-02 onward.

- [ ] **EQ-01 — Every auto-priced day rate tripled.** Open `/equipment` → a job
  → the picker. An item with a purchase cost shows **3% of it** per day, not 1%.
  Items with no purchase cost are unchanged — correct, though it may look
  inconsistent beside the others.
  *Adam's audit says all 33 rows re-derive. Any open quote that should keep old
  pricing needs `day_rate_override` pinned BEFORE this is used in anger.*

- [ ] **EQ-02 — The quote denominates once.** On a **draft** job, set Currency to
  **GBP**. Every figure — line rates, line totals, subtotal, discount, total —
  moves together. No dollar sign survives anywhere on the page.
  *A mixed pair is the failure this item exists to prevent; one stale `$` is a
  fail, not a nitpick.*

- [ ] **EQ-03 — The rate is visible and dated.** Under the currency selector:
  `1 USD = x.xxxx GBP · <date> · live`. Export the PDF — the same figures, same
  currency, converted.
  *A converted price with no visible rate is unauditable and this goes to
  clients.*

- [ ] **EQ-04 — The rate FREEZES on commit.** With the job in GBP, change status
  **draft → confirmed**. The rate line now reads **frozen**, and the currency
  selector is **disabled**. Re-open tomorrow: the same numbers, not the day's
  rate.
  *A client who accepted Tuesday's number must not open Friday's.*

- [ ] **EQ-05 — Search + multi-select.** Type in the picker's search (name,
  category, serial). Shift-click a range. Set "Qty each", Add. Then **re-add an
  item already on the quote** — its quantity should go UP, not produce a second
  identical line.

**Not built: the drag-in grid (item 5).** Assessed and stopped — see the running
report. The line table would port with no primitive change; drag-from-list does
not exist on `SpreadsheetGrid` and adding it changes a primitive Budget, Channel
list, Routing and Payroll all mount. Adam's trade.

---

## Still to do — Equipment quote R2

- [ ] **EQ-R2-01 — The picker selects by row, with per-row values.** Open a job
  → **Add items**. Click a row: it takes the orange treatment and reveals its
  **own Qty and Rate**. Click a second row — it gets its own pair. Set **3** on
  one and **1** on the other, Add: two lines land with the right quantities.
  *One global "qty each" across a mixed selection was the thing being replaced;
  if you can still find one field governing everything, that's a fail.*
  Also: shift-click still ranges, no checkboxes anywhere, and typing in a Qty
  box must not deselect the row.

- [ ] **EQ-R2-02 — The add panel folds.** On a quote **with lines** the panel
  starts **collapsed**; on an empty one it starts **open**. Toggle it, reload —
  your choice persists. Select two rows, collapse: the header still says
  "2 selected".

- [ ] **EQ-R2-03 — The title clears the bar. NEEDS BOTH WIDTHS.** `/equipment`
  at **~1500** and **~1900**: **RENTAL JOBS** is fully visible, tops of the
  letters not shaved.
  *I could not reproduce this — no browser at your widths. I fixed the mechanism
  I can prove (a tight line-height clipped inside an overflow-hidden shell). If
  it is actually OVERLAP with the tab bar, this will not fix it — say so and it
  becomes a different finding.*

- [ ] **EQ-R2-04 — Pricing rows sit on one line each.** In PRICING:
  **Items subtotal**, the discount row and **Total** each keep label and figure
  on one line, figures in mono on a shared right edge. Narrow the window until
  the labels truncate — the figures must never wrap or collide.

- [ ] **EQ-R2-05 — Edit opens, and dates save.** On a job, click **Edit**.
  *The dialog should appear at all* — it never did.
  Change the start and end dates, save. Then confirm the derived numbers moved:
  **billable days** changes, and **every line subtotal and the total** change
  with it.
  *That last half has never been exercised, because nothing ever saved.*

- [ ] **EQ-R2-06 — Currency actually converts. NEEDS MIGRATION 253 PASTED.**
  Switch a **draft** quote USD → GBP and check the **numbers**, not the symbol:
  each line's day rate, each line total, items subtotal, discount, total.
  Rate and date visible. Then **confirm the job** and re-export the PDF — it
  must use the **frozen** rate.
  *The failure to hunt is the one I already caught once: new symbol over an
  unconverted number.*

---

## Still to do — the line-table grid port

- [ ] **EQ-R2-07 — The line table is a grid and still adds up.** Open a job with
  lines. The table is now a spreadsheet grid: thumbnail, Item, Category, Qty,
  Day rate, Line total. Totals in the PRICING card match what they were before.

- [ ] **EQ-R2-08 — Editing in place saves and re-derives.** Click a **Qty** cell,
  type 3, Enter. The line total and the pricing card update. Reload — it stuck.
  Same for **Day rate**.
  *Watch the rate especially in a GBP quote: type a GBP figure, reload, and it
  must come back as the SAME GBP figure. If it drifts, the USD round-trip is
  wrong.*

- [ ] **EQ-R2-09 — Row delete still works** via the grid's row menu, and the
  totals drop accordingly.

*Known and deliberate: the **Item** cell is read-only. It cannot be an
`entityRef: 'gear'` cell until the picker writes `gear_id` — see the running
report. To change what an item is, delete the line and re-add it.*

---

## Already verified on `431f316` (Cowork, no need to repeat)

- **SHELL-01 — The shell renders on Routing.** Top bar: workspace · artist/tour
  picker · TOUR/MONEY/PRODUCTION pill · avatar. Left rail grouped THE RUN /
  PEOPLE & LOGISTICS.
- **SHELL-02 — Tour mode active, Routing item active** on cold load.
- **SHELL-03 — The identity band is gone on Routing** (the top bar carries
  artist + tour; showing both would state it twice).
- **SHELL-04 — The routing ledger still works** underneath the new chrome.
- **Money pill → `/budget/[id]?tab=summary`** renders on its old chrome, which is
  correct until S-2b.

---

## Known and logged — don't file these again

- **The rail defaults to collapsed on Routing** even though no day rail competes
  for width there. My error: `RoutingRail` is rendered by Rooming, Day and
  Advance, *not* by the routing page. Fixed in S-2a.
- **The picker flashes "Pick an artist…"** for one frame on cold load. The layout
  knows the artist server-side; threading it through is S-2a.
- **`/assets` vs `/equipment`** — both work, both light the same rail item. The
  rename is Adam's call, deliberately not decided.

---

## If something is broken

The failure mode that bit S-1 was an **RSC boundary** error: "Something went
wrong" from the error boundary, with the page never rendering. If you see that:

1. Note which pages fail and which don't. If *only* migrated pages fail, it's in
   the shell; if *everything* fails, suspect the middleware.
2. Grab the digest numbers from the response — they map to a real stack in the
   Vercel runtime logs (Deployment → Functions, filter by digest).
3. The usual cause is a **function** being passed from a server component to a
   client component. `tsc`, `eslint`, `next build` and the jsdom tests all pass
   on that mistake, so the live page is the only thing that catches it.


---

## S-3b — workspace + You cross; the migration completes (2026-08-04)

- [ ] **SHELL-60 — The workspace tier has the rail now.** Open `/artists`.
  Left rail: WORKSPACE head, then Artists / Personnel pool / Equipment &
  rentals / Venues. Top bar shows the REAL workspace name (not "Workspace").
  The old horizontal tab strip is gone; nothing renders twice.
  *The "no rail at workspace tier" rule was reversed deliberately — Adam's
  call, 2026-08-04.*

- [ ] **SHELL-61 — Each workspace item lights on its own page.** /artists →
  Artists active; /personnel → Personnel pool; /assets → Equipment & rentals;
  /venues → Venues. /equipment (legacy) also lights Equipment & rentals.

- [ ] **SHELL-62 — You scope is shelled.** /settings, /settings/members,
  /settings/ai-limits, /profile, /bugs each render the YOU rail (Account /
  Preferences / Team & roles / Billing / Report a bug) with the right item
  active. Billing is dimmed — no page yet, and it says so on hover.

- [ ] **SHELL-63 — /profile is off shell-v1.** No shell-v1 list rail on the
  left; the YOU rail with Account active instead. The profile form still
  saves.

- [ ] **SHELL-64 — The tourless landings grey the bar, not the rail.** Open
  /operations (also /budget, /advance) with NO tour remembered. The workspace
  rail is fully visible and interactive; the top bar shows the mode pill
  GREYED (not absent, not clickable, tooltip explains) and a live artist/tour
  picker; the "Select a tour" prompt shows beneath. Picking a tour navigates
  and the pill comes alive.

- [ ] **SHELL-65 — A remembered tour still skips the landing.** With a tour in
  context, /operations hard-replaces to /operations/[tourId] as before.

- [ ] **SHELL-66 — The standalone rider editor joined the artist library.**
  Open a pack at /rider-packs/[id]. ARTIST-scope rail, "Riders & specs" lit,
  rail starts COLLAPSED (the pack sidebar keeps its width). The ↑ goes to
  Workspace. Editing (?mode=edit) keeps the same chrome.

- [ ] **SHELL-67 — The workspace switcher is on every tier now.** Top-right
  (left of the avatar) on a tour page, an artist page, /artists and /settings.
  Single-workspace users see a plain label, multi-workspace users a control.
  *shell-v2's ProductHeader mounted this and the v3 bar didn't — S-3b closed
  the regression.*

- [ ] **SHELL-68 — Nothing double-renders anywhere.** Walk /artists →
  /artists/[id] → a tour → /budget/[tourId] → /settings → /rider-packs/[id]:
  exactly ONE top bar and ONE app rail on every page, and the ⌘K palette,
  bug-report button and toasts still mount once.
